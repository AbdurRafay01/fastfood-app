-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 08, 2021 at 07:05 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_food`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `adminid` int(2) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`adminid`, `name`, `username`, `password`) VALUES
(1, 'Abdur Rafay', 'abrafay', '4321'),
(15, 'Humza Ali', 'humza918', '37ggdf343');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cartid` int(4) NOT NULL,
  `ProductId` varchar(2) DEFAULT NULL,
  `Quantity` int(20) DEFAULT NULL,
  `Date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cartid`, `ProductId`, `Quantity`, `Date`) VALUES
(9, '13', 4, '2021-02-08'),
(10, '12', 7, '2021-02-08'),
(11, '29', 6, '2021-02-08'),
(12, '25', 4, '2021-02-08');

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `Paymentid` int(2) NOT NULL,
  `PaymentDate` date DEFAULT NULL,
  `Amount` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `ProductId` int(4) NOT NULL,
  `Name` varchar(20) DEFAULT NULL,
  `Quantity` int(20) DEFAULT NULL,
  `Price` int(20) DEFAULT NULL,
  `Category` varchar(20) DEFAULT NULL,
  `img_path` varchar(50) DEFAULT NULL,
  `Description` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`ProductId`, `Name`, `Quantity`, `Price`, `Category`, `img_path`, `Description`) VALUES
(12, 'Cheese Burger', 14, 523, 'Burger', 'fullcheeseburger.jpg', 'Our simple, succulent 100% chicken breast Fillet burger, plus spine-tingling Zing. With regular fries and a regular drink.'),
(13, 'beef Burger', 6, 420, 'Burger', 'beefburger.jpg', 'Our simple, succulent 100% beef burger, plus spine-tingling Zing. With regular fries and a regular drink.'),
(15, 'Tikka Pizza', 10, 1000, 'Pizza', 'tikkapizza.jpg', ''),
(16, 'Beef Pizza', 8, 780, 'Pizza', 'beefpizza.jpg', ''),
(25, 'Mayo Galic Roll', 34, 30, 'Roll', 'mayoroll.jpg', ''),
(29, 'Chatni Roll', 23, 120, 'Roll', 'chatniroll.jpg', '');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `TransactionId` int(2) NOT NULL,
  `ProductId` int(2) DEFAULT NULL,
  `PaymentId` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`adminid`),
  ADD UNIQUE KEY `username` (`username`,`password`),
  ADD UNIQUE KEY `username_2` (`username`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cartid`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`Paymentid`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`ProductId`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`TransactionId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `adminid` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cartid` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

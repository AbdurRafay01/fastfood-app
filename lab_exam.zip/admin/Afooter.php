<div class="footer11">
    <div class="container">
        <div class="row">
            <div class="col-sm-8">
                <form class="emailform">

                    <div class="form-group">
                        <p>Subscribe to Us</p>
                        <div class="inline-button">
                            <input type="email" class="form-control" id="exampleInputEmail1"
                                aria-describedby="emailHelp" placeholder="Enter email address">
                            <button type="button" class="btn"
                                style="color:white;background-color:rgb(235, 116, 5)">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="col-sm-4">
                <div class="contacts itemgf-1">


                    <p id="contactus">Contacts Us</p>
                    <div class="footer11-links itemgf-2">
                    </div>
                    <br>
                    <ul class="footer11-links foot-list">
                        <li>
                            <a href="mailto:">abc@outlook.com</a>
                        </li>
                        <li>
                            <a href="tel:+"> +92 03754324326</a>
                        </li>
                        <li>
                            <a href="tel:+">+92 03996457744</a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-6">
                <div class="itemgf-3">
                    <p>Follow Us</p>
                    <ul>
                        
                        <li><a href="#"><img src="../static/img/facebook.svg" alt=""></a>
                        </li>

                        <li><a href="#"><img src="../static/img/instagram.svg" alt=""></a>
                        </li>

                        <li><a href="#"><img src="../static/img/twitter.svg" alt=""></a>
                        </li>

                    </ul>
                </div>
            </div>
            <div class="footer11-links col-sm-6">
                <div class="itemgf-2">
                </div>
                <br>
                <p>
                    <a href="../home.php">Home</a>
                    <a href="../about.php">About Us</a>
                    <a href="../fastfood.php">Fast Food</a>
                    <a href="../contact.php">Contact Us</a>
                </p>
            </div>
        </div>
    </div>
</div>
<a href="#">
    <object class="to-top" data="../static/img/arrow_up.svg" type="image/svg+xml">
    </object>
</a>
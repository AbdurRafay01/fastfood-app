<?php
        // database connection
        // echo "Database connected";
        
        $conn = mysqli_connect('localhost', 'root', '', 'online_food');
?>
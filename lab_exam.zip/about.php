<?php
    include "includes/header.php";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous">
    </script>
    <link rel="stylesheet" href="static\css\user.css">
    <!-- footer -->
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- footerend -->
</head>

<body>
    

    <div class="aboutus">
        <img src="static\img\freshcook.png" alt="">
        <h1>Introduction</h1>

        <br>
        <p style="padding-bottom: 50px;">
        The ADC Resturant Restaurants are an illustration of thoughtful dinning, exceptional help, uncommon work of art and contemporary food. The cafés have become a definitive dinning objections in Lahore. From family events to business suppers and snapshots of the heart, this spot is the place where life-changing recollections are made.

            <br>
            <br>
            

        </p>


        <h1 style="padding-top: 50px;">Our Customers
        </h1>

        <h2>Customer Care</h2>
        <p>
            Customers are very important to us and we care about them very much
        </p>

    </div>



</html>


<?php
    include "includes/footer.php";
    ?>
</body>

</html>